<?php header("Content-Type: text/plain");?>
User-agent: *
Allow: /
Sitemap: https://<?php echo $_SERVER['HTTP_HOST'];?>/sitemap.xml