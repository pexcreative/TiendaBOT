<?php
$empresa = 'co-27jeans.com';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad - <?php echo $empresa;?></title>

    <!-- Enlaces a los archivos CSS de Bootstrap desde CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Enlace a un archivo CSS personalizado para tu empresa -->
    <link rel="stylesheet" href="tu-archivo-de-estilos.css">
</head>
<body>

<!-- Barra de navegación -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#FFC600;">
    <div class="container">
        <a class="navbar-brand" href="https://avellanedaonline.com"><strong><?php echo $empresa;?></strong></a>

    </div>
</nav>

<!-- Contenido de la Política de Privacidad -->
<div class="container mt-5">
    <h1>Política de Privacidad de <?php echo $empresa;?></h1>

    <p>En <?php echo $empresa;?>, valoramos la privacidad y la protección de datos de nuestros usuarios. Esta política de privacidad describe cómo recopilamos, utilizamos y protegemos la información personal que nos proporciona al utilizar nuestro sitio web.</p>

    <h2>Información que Recopilamos</h2>
    <p>Recopilamos información personal como nombre, dirección de correo electrónico, y detalles de contacto cuando usted interactúa con nuestro sitio, realiza una compra o se registra en nuestra plataforma. También recopilamos información de manera automática, como direcciones IP y datos de navegación.</p>

    <h2>Uso de la Información</h2>
    <p>La información que recopilamos se utiliza para mejorar su experiencia en nuestro sitio web, procesar sus pedidos y brindarle información relevante sobre nuestros productos y servicios. No compartimos su información con terceros sin su consentimiento explícito.</p>

    <h2>Protección de Datos</h2>
    <p>Tomamos medidas para proteger sus datos personales y garantizar la seguridad de la información que nos proporciona. Utilizamos prácticas de seguridad estándar de la industria y tecnologías de cifrado para proteger sus datos.</p>

    <h2>Cookies</h2>
    <p>Nuestro sitio web utiliza cookies para mejorar la funcionalidad y personalizar su experiencia. Puede administrar las preferencias de cookies en su navegador.</p>

    <h2>Contacto</h2>
    <p>Si tiene alguna pregunta sobre nuestra política de privacidad o el uso de sus datos personales, <a href="/contacto">contáctenos</a>.</p>

</div>

<!-- Scripts de Bootstrap desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
