<?php 
$replaceIds = array(
	array(
		"TEXT_SEARCH" => "BRAND",
		"REPLACE_FOR" => "MARCA"
	),
	
	array(
		"TEXT_SEARCH" => "CARRIER",
		"REPLACE_FOR" => "OPERADORA"
	)
	
);
?>